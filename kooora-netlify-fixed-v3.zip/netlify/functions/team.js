const { json, mapLeagueId } = require('./helpers');
const SPORTSDB_KEY = '123';

async function fetchTeamBySearch(name){
  if (!name) return null;
  try {
    const url = `https://www.thesportsdb.com/api/v1/json/${SPORTSDB_KEY}/searchteams.php?t=${encodeURIComponent(name)}`;
    const res = await fetch(url);
    if (!res.ok) return null;
    const data = await res.json();
    const teams = Array.isArray(data && data.teams) ? data.teams : [];
    return teams[0] || null;
  } catch (e) {
    return null;
  }
}

async function fetchUpcoming(teamId){
  if (!teamId) return [];
  try {
    const url = `https://www.thesportsdb.com/api/v1/json/${SPORTSDB_KEY}/eventsnext.php?id=${encodeURIComponent(teamId)}`;
    const res = await fetch(url);
    if (!res.ok) return [];
    const data = await res.json();
    const events = Array.isArray(data && data.events) ? data.events : [];
    return events.slice(0, 8).map(e => ({
      date: e.dateEvent || '',
      time: e.strTime ? String(e.strTime).slice(0,5) : '',
      home: e.strHomeTeam || '',
      away: e.strAwayTeam || '',
      league: e.strLeague || ''
    }));
  } catch (e) {
    return [];
  }
}

async function fetchApiFootballTeam(teamId, leagueId, name, token){
  const meta = mapLeagueId(leagueId);
  if (!token || !meta || !meta.apiFootball) return { team: null, upcoming: [] };
  const y = new Date().getFullYear();
  const m = new Date().getMonth() + 1;
  const season = m >= 7 ? y : y - 1;
  let team = null;
  let upcoming = [];
  try {
    if (teamId) {
      const url1 = `https://v3.football.api-sports.io/teams?id=${encodeURIComponent(teamId)}`;
      const res1 = await fetch(url1, { headers: { 'x-apisports-key': token } });
      if (res1.ok) {
        const d1 = await res1.json();
        const row = Array.isArray(d1 && d1.response) ? d1.response[0] : null;
        if (row) {
          team = {
            name: row.team && row.team.name,
            badge: row.team && row.team.logo,
            country: row.team && row.team.country,
            formed: row.team && row.team.founded,
            stadium: row.venue && row.venue.name,
            website: '',
            description: ''
          };
        }
      }
      const url2 = `https://v3.football.api-sports.io/fixtures?team=${encodeURIComponent(teamId)}&league=${meta.apiFootball}&season=${season}&next=8`;
      const res2 = await fetch(url2, { headers: { 'x-apisports-key': token } });
      if (res2.ok) {
        const d2 = await res2.json();
        const rows = Array.isArray(d2 && d2.response) ? d2.response : [];
        upcoming = rows.map(r => ({
          date: r.fixture && r.fixture.date ? String(r.fixture.date).slice(0,10) : '',
          time: r.fixture && r.fixture.date ? new Date(r.fixture.date).toISOString().slice(11,16) : '',
          home: r.teams && r.teams.home ? r.teams.home.name : '',
          away: r.teams && r.teams.away ? r.teams.away.name : '',
          league: r.league && r.league.name ? r.league.name : ''
        }));
      }
    }
  } catch (e) {}
  return { team, upcoming };
}

exports.handler = async function(event){
  try {
    const teamId = event.queryStringParameters && event.queryStringParameters.teamId ? event.queryStringParameters.teamId : '';
    const name = event.queryStringParameters && event.queryStringParameters.name ? event.queryStringParameters.name : '';
    const league = event.queryStringParameters && event.queryStringParameters.league ? event.queryStringParameters.league : '';
    const token = process.env.FOOTBALL_DATA_TOKEN || '';

    let rawTeam = await fetchTeamBySearch(name);
    let team = rawTeam ? {
      name: rawTeam.strTeam || name,
      badge: rawTeam.strBadge || '',
      country: rawTeam.strCountry || '',
      formed: rawTeam.intFormedYear || '',
      stadium: rawTeam.strStadium || '',
      website: rawTeam.strWebsite ? `https://${String(rawTeam.strWebsite).replace(/^https?:\/\//,'')}` : '',
      description: rawTeam.strDescriptionEN || rawTeam.strDescriptionFR || rawTeam.strDescriptionES || ''
    } : null;

    const effectiveId = teamId || (rawTeam && rawTeam.idTeam) || '';
    let upcoming = await fetchUpcoming(effectiveId);

    if ((!team || !upcoming.length) && token) {
      const extra = await fetchApiFootballTeam(effectiveId, league, name, token);
      if (!team && extra.team) team = extra.team;
      if (!upcoming.length && extra.upcoming.length) upcoming = extra.upcoming;
    }

    return json(200, {
      team: team || { name },
      upcoming
    });
  } catch (e) {
    return json(500, { error: 'Failed to load team' });
  }
};
