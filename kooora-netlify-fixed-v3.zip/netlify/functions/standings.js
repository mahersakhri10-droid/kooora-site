const { json, mapLeagueId, seasonCandidates } = require("./helpers");
const SPORTSDB_KEY = "123";

async function fetchSportsDbStandings(leagueId) {
  const meta = mapLeagueId(leagueId);
  if (!meta || !meta.sportsDb) return [];
  try {
    for (const season of seasonCandidates()) {
      const url = `https://www.thesportsdb.com/api/v1/json/${SPORTSDB_KEY}/lookuptable.php?l=${meta.sportsDb}&s=${season}`;
      const res = await fetch(url);
      if (!res.ok) continue;
      const data = await res.json();
      const table = Array.isArray(data && data.table) ? data.table : [];
      if (!table.length) continue;
      return table.map((r, i) => ({
        position: Number(r.intRank || i + 1),
        team: r.strTeam || "",
        team_id: r.idTeam || "",
        played: Number(r.intPlayed || 0),
        won: Number(r.intWin || 0),
        draw: Number(r.intDraw || 0),
        lost: Number(r.intLoss || 0),
        gf: Number(r.intGoalsFor || 0),
        ga: Number(r.intGoalsAgainst || 0),
        pts: Number(r.intPoints || 0),
        source: "TheSportsDB"
      }));
    }
    return [];
  } catch (err) {
    return [];
  }
}

async function fetchApiFootballStandings(leagueId, token) {
  const meta = mapLeagueId(leagueId);
  if (!meta || !meta.apiFootball || !token) return [];
  const y = new Date().getFullYear();
  const m = new Date().getMonth() + 1;
  const season = m >= 7 ? y : y - 1;
  const url = `https://v3.football.api-sports.io/standings?league=${meta.apiFootball}&season=${season}`;
  try {
    const res = await fetch(url, { headers: { "x-apisports-key": token } });
    if (!res.ok) return [];
    const data = await res.json();
    const groups = data && data.response && data.response[0] && data.response[0].league && data.response[0].league.standings ? data.response[0].league.standings : [];
    const table = Array.isArray(groups) && Array.isArray(groups[0]) ? groups[0] : [];
    return table.map((r) => ({
      position: r.rank || 0,
      team: r.team ? r.team.name : "",
      team_id: r.team ? r.team.id : "",
      played: r.all ? r.all.played : 0,
      won: r.all ? r.all.win : 0,
      draw: r.all ? r.all.draw : 0,
      lost: r.all ? r.all.lose : 0,
      gf: r.all && r.all.goals ? r.all.goals.for : 0,
      ga: r.all && r.all.goals ? r.all.goals.against : 0,
      pts: r.points || 0,
      source: "API-Football"
    }));
  } catch (err) {
    return [];
  }
}

exports.handler = async function (event) {
  try {
    const leagueId = event.queryStringParameters && event.queryStringParameters.league ? event.queryStringParameters.league : "epl";
    const token = process.env.FOOTBALL_DATA_TOKEN || "";
    let standings = await fetchSportsDbStandings(leagueId);
    if ((!standings || standings.length === 0) && token) {
      standings = await fetchApiFootballStandings(leagueId, token);
    }
    return json(200, { league: leagueId, standings });
  } catch (err) {
    return json(500, { error: "Failed to load standings" });
  }
};
