const esc = (s)=> String(s ?? "").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;");
const qs = (k)=> new URLSearchParams(location.search).get(k);

const LEAGUES = {
  epl: "الدوري الإنجليزي الممتاز",
  laliga: "الدوري الإسباني",
  seriea: "الدوري الإيطالي",
  bundesliga: "الدوري الألماني",
  ligue1: "الدوري الفرنسي",
  ucl: "دوري أبطال أوروبا",
  ksa: "الدوري السعودي",
  egy: "الدوري المصري",
  mar: "الدوري المغربي",
  tun: "الدوري التونسي",
  alg: "الدوري الجزائري",
  cafcl: "دوري أبطال أفريقيا"
};

const DEFAULT_MOST_READ = [
  "قمة مرتقبة في الدوري الإنجليزي اليوم",
  "الهلال والنصر.. صراع الصدارة يشتعل",
  "ليلة أوروبية كبيرة في دوري الأبطال",
  "الأهلي والزمالك.. كلاسيكو الكرة المصرية",
  "سباق اللقب يشتعل في الليغا",
  "نتائج اليوم وترتيب أبرز الدوريات"
];

const DEFAULT_HERO = {
  title: "كووورة كلاسيك",
  sub: "مباريات اليوم، الترتيب الكامل، وصفحات للأندية"
};

async function getJSON(url){
  const r = await fetch(url);
  if(!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.json();
}

function loadConfig(){
  let cfg = {};
  try { cfg = JSON.parse(localStorage.getItem('koooraClassicConfig') || '{}'); } catch(e) {}
  return {
    heroTitle: cfg.heroTitle || DEFAULT_HERO.title,
    heroSub: cfg.heroSub || DEFAULT_HERO.sub,
    mostRead: Array.isArray(cfg.mostRead) && cfg.mostRead.length ? cfg.mostRead : DEFAULT_MOST_READ
  };
}

function saveConfig(cfg){
  localStorage.setItem('koooraClassicConfig', JSON.stringify(cfg));
}

function topBars(active){
  const time = new Date().toLocaleTimeString("ar", {hour:"2-digit", minute:"2-digit"});
  return `
    <div class="langbar"><div class="row"><div>واجهة رياضية كلاسيكية</div><div>${time}</div></div></div>
    <div class="header"><div class="row"><div class="logo"><div class="mark"></div><div class="name">KOOORA <span>Classic</span></div></div><div><span class="pill">بحث</span> <span class="pill">مفضلاتي</span> <a class="pill pill-link" href="./admin.html">لوحة التحكم</a></div></div></div>
    <div class="nav"><div class="row">
      <a class="${active==='home'?'active':''}" href="./index.html">الرئيسية</a>
      <a class="${active==='news'?'active':''}" href="./news.html">الأخبار</a>
      <a class="${active==='matches'?'active':''}" href="./index.html#matches">المباريات</a>
      <a class="${active==='leagues'?'active':''}" href="./index.html#leagues">الدوريات</a>
    </div></div>`;
}

function panel(title, rightHtml, bodyHtml){
  return `<div class="panel"><div class="ph"><div>${esc(title)}</div><div>${rightHtml || ""}</div></div><div class="pb">${bodyHtml}</div></div>`;
}

function leaguesBlock(){
  const world = ["ucl","epl","laliga","seriea","bundesliga","ligue1"];
  const arab = ["ksa","egy","mar","tun","alg","cafcl"];
  return `
    <div class="links">
      <div class="muted small" style="margin-bottom:6px"><b>الدوريات العالمية</b></div>
      ${world.map(id=>`<a href="./league.html?id=${id}">${esc(LEAGUES[id])}</a>`).join("")}
      <div class="muted small" style="margin:10px 0 6px"><b>الدوريات العربية</b></div>
      ${arab.map(id=>`<a href="./league.html?id=${id}">${esc(LEAGUES[id])}</a>`).join("")}
    </div>`;
}

function heroBlock(){
  const cfg = loadConfig();
  return `
    <div class="hero"><div class="bg"></div><div class="cap">${esc(cfg.heroTitle)}<span class="sub">${esc(cfg.heroSub)}</span></div></div>
    <div class="cards">
      <div class="card"><div class="thumb"></div><div class="ct">ترتيب كامل للدوريات وصفحات مستقلة للأندية</div></div>
      <div class="card"><div class="thumb"></div><div class="ct">مباريات اليوم مع ربط تلقائي مجاني</div></div>
      <div class="card"><div class="thumb"></div><div class="ct">لوحة تحكم بسيطة لتخصيص المحتوى الرئيسي</div></div>
    </div>`;
}

function mostReadBlock(){
  const cfg = loadConfig();
  return `<ul class="clean">${cfg.mostRead.map(x=>`<li><a href="./news.html">${esc(x)}</a></li>`).join('')}</ul>`;
}

function renderError(message){ return `<div class="error">${esc(message)}</div>`; }

function teamLink(teamName, teamId, leagueId){
  return `./team.html?league=${encodeURIComponent(leagueId)}&teamId=${encodeURIComponent(teamId || '')}&name=${encodeURIComponent(teamName || '')}`;
}

export async function renderHome(root){
  root.innerHTML = `${topBars('home')}<div class="container"><div class="grid"><div>${panel('مباريات اليوم','<span class="badge">تحميل...</span>','<div class="muted">جارٍ التحميل...</div>')}${panel('أهم الدوريات','',leaguesBlock())}</div><div>${panel('الأبرز','',heroBlock())}${panel('الأخبار الأكثر قراءة','',mostReadBlock())}</div><div>${panel('مختارات','',mostReadBlock())}</div></div><div class="footer">كووورة كلاسيك — نسخة جاهزة للنشر</div></div>`;

  try{
    const data = await getJSON('/.netlify/functions/matches?leagues=epl,laliga,seriea,bundesliga,ligue1,ucl,ksa,egy');
    const left = panel('مباريات اليوم', `<span class="badge">${esc(data.date || '')}</span>`, `
      <table class="table">
        <thead><tr><th style="width:70px">الوقت</th><th>المباراة</th><th style="width:70px">الحالة</th></tr></thead>
        <tbody>
          ${(data.matches || []).length ? data.matches.map(m=>`
            <tr>
              <td>${esc(m.time || '--:--')}</td>
              <td class="match"><a href="./match.html?id=${encodeURIComponent(m.id)}&league=${encodeURIComponent(m.league_id)}&home=${encodeURIComponent(m.home)}&away=${encodeURIComponent(m.away)}">${esc(m.home)} × ${esc(m.away)}</a><div class="muted small"><a href="./league.html?id=${encodeURIComponent(m.league_id)}">${esc(m.league_name)}</a></div></td>
              <td>${esc(m.status || '-')}</td>
            </tr>`).join('') : `<tr><td colspan="3">لا توجد بيانات اليوم.</td></tr>`}
        </tbody>
      </table>`);
    const grid = root.querySelector('.grid');
    grid.children[0].innerHTML = left + panel('أهم الدوريات','',leaguesBlock());
  }catch(e){
    const grid = root.querySelector('.grid');
    grid.children[0].innerHTML = panel('مباريات اليوم','',renderError('تعذر تحميل مباريات اليوم. تأكد من أن الرابط /.netlify/functions/matches يعمل.')) + panel('أهم الدوريات','',leaguesBlock());
  }
}

export async function renderLeague(root){
  const league = qs('id') || 'epl';
  root.innerHTML = `${topBars('leagues')}<div class="container">${panel('الترتيب','<span class="badge">تحميل...</span>','<div class="muted">جارٍ التحميل...</div>')}</div>`;
  try{
    const data = await getJSON(`/.netlify/functions/standings?league=${encodeURIComponent(league)}`);
    root.innerHTML = `${topBars('leagues')}<div class="container">${panel(`ترتيب الدوري: ${LEAGUES[league] || league}`,'',`
      <table class="table"><thead><tr><th>#</th><th>الفريق</th><th>لعب</th><th>ف</th><th>ت</th><th>خ</th><th>له</th><th>عليه</th><th>نقاط</th></tr></thead><tbody>
      ${(data.standings || []).length ? data.standings.map(s=>`<tr><td>${s.position}</td><td><a href="${teamLink(s.team, s.team_id, league)}">${esc(s.team)}</a></td><td>${s.played}</td><td>${s.won}</td><td>${s.draw}</td><td>${s.lost}</td><td>${s.gf}</td><td>${s.ga}</td><td><b>${s.pts}</b></td></tr>`).join('') : `<tr><td colspan="9">لا توجد بيانات ترتيب لهذا الدوري الآن.</td></tr>`}
      </tbody></table>
      <div class="muted small" style="margin-top:8px">إذا ظهر الترتيب ناقصًا في بعض الدوريات فهذه حدود المصدر المجاني الحالي، ويمكن توسيعه لاحقًا بمصدر إضافي أو مفتاح مجاني آخر.</div>`)}${panel('دوريات أخرى','',leaguesBlock())}</div>`;
  }catch(e){
    root.innerHTML = `${topBars('leagues')}<div class="container">${panel('الترتيب','',renderError('تعذر تحميل الترتيب. تأكد من أن الرابط /.netlify/functions/standings?league=epl يعمل.'))}</div>`;
  }
}

export async function renderTeam(root){
  const teamId = qs('teamId') || '';
  const teamName = qs('name') || '';
  const league = qs('league') || '';
  root.innerHTML = `${topBars('leagues')}<div class="container">${panel('الفريق','<span class="badge">تحميل...</span>','<div class="muted">جارٍ التحميل...</div>')}</div>`;
  try{
    const data = await getJSON(`/.netlify/functions/team?teamId=${encodeURIComponent(teamId)}&name=${encodeURIComponent(teamName)}&league=${encodeURIComponent(league)}`);
    const team = data.team || {};
    const upcoming = data.upcoming || [];
    root.innerHTML = `${topBars('leagues')}<div class="container">${panel(team.name || teamName,'',`
      <div class="team-box">
        <div class="team-logo-wrap">${team.badge ? `<img class="team-logo" src="${esc(team.badge)}" alt="${esc(team.name || teamName)}">` : `<div class="team-logo team-logo-empty"></div>`}</div>
        <div class="team-meta">
          <div><b>الدوري:</b> <a href="./league.html?id=${encodeURIComponent(league)}">${esc(LEAGUES[league] || league)}</a></div>
          <div><b>الاسم:</b> ${esc(team.name || teamName)}</div>
          ${team.country ? `<div><b>الدولة:</b> ${esc(team.country)}</div>` : ''}
          ${team.formed ? `<div><b>سنة التأسيس:</b> ${esc(team.formed)}</div>` : ''}
          ${team.stadium ? `<div><b>الملعب:</b> ${esc(team.stadium)}</div>` : ''}
          ${team.website ? `<div><b>الموقع:</b> <a href="${esc(team.website)}" target="_blank" rel="noopener">${esc(team.website)}</a></div>` : ''}
        </div>
      </div>
      ${team.description ? `<div class="team-description">${esc(team.description)}</div>` : ''}
    `)}
    ${panel('المباريات القادمة','', upcoming.length ? `<table class="table"><thead><tr><th>التاريخ</th><th>المباراة</th><th>البطولة</th></tr></thead><tbody>${upcoming.map(m=>`<tr><td>${esc(m.date || '')} ${esc(m.time || '')}</td><td>${esc(m.home)} × ${esc(m.away)}</td><td>${esc(m.league || '')}</td></tr>`).join('')}</tbody></table>` : `<div class="muted">لا توجد مباريات قادمة متاحة حاليًا.</div>`)}
    ${panel('أخبار الفريق','', `<div class="muted">تم تجهيز صفحة الفريق. الأخبار المتخصصة لكل فريق تحتاج مصدر أخبار منفصل أو لوحة تحكم متصلة بقاعدة بيانات. أستطيع إضافتها في الخطوة التالية.</div>`)}
    </div>`;
  } catch(e) {
    root.innerHTML = `${topBars('leagues')}<div class="container">${panel('الفريق','',renderError('تعذر تحميل بيانات الفريق.'))}</div>`;
  }
}

export function renderMatch(root){
  const home = qs('home') || '';
  const away = qs('away') || '';
  const league = qs('league') || '';
  root.innerHTML = `${topBars('matches')}<div class="container">${panel('المباراة','',`
    <table class="table"><tbody>
      <tr><th style="width:160px">الدوري</th><td><a href="./league.html?id=${encodeURIComponent(league)}">${esc(LEAGUES[league] || league)}</a></td></tr>
      <tr><th>المباراة</th><td><b>${esc(home)} × ${esc(away)}</b></td></tr>
      <tr><th>ملاحظة</th><td>هذه الصفحة مختصرة. تفاصيل الأهداف والبطاقات تحتاج endpoint إضافي.</td></tr>
    </tbody></table>`)} </div>`;
}

export function renderNews(root){
  root.innerHTML = `${topBars('news')}<div class="container">${panel('الأخبار','',`<div class="muted">تم نقل واجهة الصفحة الرئيسية إلى قسم الأخبار الأكثر قراءة. ويمكن لاحقًا ربط أخبار حقيقية أو إدارتها من لوحة التحكم.</div>${mostReadBlock()}`)}</div>`;
}

export function renderAdmin(root){
  const cfg = loadConfig();
  root.innerHTML = `${topBars('home')}<div class="container">${panel('لوحة التحكم','',`
    <div class="muted" style="margin-bottom:10px">هذه لوحة تحكم مبسطة تحفظ التعديلات في المتصفح الحالي. لتحويلها إلى لوحة تحكم عامة لكل الزوار نحتاج قاعدة بيانات أو Git-based CMS.</div>
    <div class="form-grid">
      <label>عنوان الواجهة الرئيسية<input id="heroTitle" value="${esc(cfg.heroTitle)}"></label>
      <label>الوصف المختصر<input id="heroSub" value="${esc(cfg.heroSub)}"></label>
      <label class="full">الأخبار الأكثر قراءة (كل سطر خبر)<textarea id="mostRead" rows="8">${esc(cfg.mostRead.join('\n'))}</textarea></label>
    </div>
    <div class="admin-actions"><button id="saveCfg">حفظ التعديلات</button> <button id="resetCfg" class="secondary">إعادة الافتراضي</button></div>
  `)}</div>`;

  document.getElementById('saveCfg').addEventListener('click', ()=>{
    const newCfg = {
      heroTitle: document.getElementById('heroTitle').value.trim() || DEFAULT_HERO.title,
      heroSub: document.getElementById('heroSub').value.trim() || DEFAULT_HERO.sub,
      mostRead: document.getElementById('mostRead').value.split('\n').map(x=>x.trim()).filter(Boolean)
    };
    saveConfig(newCfg);
    alert('تم الحفظ. عد إلى الرئيسية لترى التغييرات.');
  });

  document.getElementById('resetCfg').addEventListener('click', ()=>{
    localStorage.removeItem('koooraClassicConfig');
    location.reload();
  });
}
