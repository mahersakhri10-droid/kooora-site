const { json, mapLeagueId, todayISO, normalizeStatus } = require('./helpers');
const SPORTSDB_KEY = '123';
async function fetchSportsDbToday(leagueId) {
  const meta = mapLeagueId(leagueId);
  if (!meta || !meta.sportsDb) return [];
  const url = `https://www.thesportsdb.com/api/v1/json/${SPORTSDB_KEY}/eventsday.php?d=${todayISO()}&id=${meta.sportsDb}`;
  try {
    const res = await fetch(url);
    if (!res.ok) return [];
    const data = await res.json();
    const events = Array.isArray(data && data.events) ? data.events : [];
    return events.filter(e => String(e.idLeague||'') === String(meta.sportsDb)).map(e => ({
      id: `sdb-${e.idEvent}`,
      league_id: leagueId,
      league_name: e.strLeague || meta.name,
      date: e.dateEvent || todayISO(),
      time: e.strTime ? String(e.strTime).slice(0,5) : '',
      home: e.strHomeTeam || '',
      away: e.strAwayTeam || '',
      status: normalizeStatus(e.strStatus),
      hs: e.intHomeScore != null ? Number(e.intHomeScore) : null,
      as: e.intAwayScore != null ? Number(e.intAwayScore) : null,
      source: 'TheSportsDB'
    }));
  } catch (e) { return []; }
}
async function fetchApiFootballToday(leagueId, token) {
  const meta = mapLeagueId(leagueId);
  if (!meta || !meta.apiFootball || !token) return [];
  const season = new Date().getUTCFullYear();
  const url = `https://v3.football.api-sports.io/fixtures?league=${meta.apiFootball}&season=${season}&date=${todayISO()}`;
  try {
    const res = await fetch(url, { headers: { 'x-apisports-key': token } });
    if (!res.ok) return [];
    const data = await res.json();
    const rows = Array.isArray(data && data.response) ? data.response : [];
    return rows.map(r => ({
      id: `af-${r.fixture?.id || Math.random().toString(36).slice(2)}`,
      league_id: leagueId,
      league_name: r.league?.name || meta.name,
      date: r.fixture?.date ? String(r.fixture.date).slice(0,10) : todayISO(),
      time: r.fixture?.date ? new Date(r.fixture.date).toISOString().slice(11,16) : '',
      home: r.teams?.home?.name || '',
      away: r.teams?.away?.name || '',
      status: r.fixture?.status?.short || '-',
      hs: r.goals?.home ?? null,
      as: r.goals?.away ?? null,
      source: 'API-Football'
    }));
  } catch (e) { return []; }
}
exports.handler = async function(event) {
  try {
    const leaguesParam = event.queryStringParameters?.leagues || 'epl,laliga,seriea,bundesliga,ligue1,ucl,ksa,egy';
    const leagues = leaguesParam.split(',').map(s => s.trim()).filter(Boolean);
    const token = process.env.FOOTBALL_DATA_TOKEN || '';
    const all = [];
    for (const leagueId of leagues) {
      let rows = await fetchSportsDbToday(leagueId);
      if ((!rows || !rows.length) && token) rows = await fetchApiFootballToday(leagueId, token);
      all.push(...rows);
    }
    all.sort((a,b) => String(a.time||'').localeCompare(String(b.time||'')));
    return json(200, { date: todayISO(), matches: all });
  } catch (e) { return json(500, { error: 'Failed to load matches' }); }
};
