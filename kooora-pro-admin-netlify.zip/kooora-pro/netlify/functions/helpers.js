function json(statusCode, data) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "public, max-age=120"
    },
    body: JSON.stringify(data)
  };
}
function mapLeagueId(id) {
  const map = {
    epl: { sportsDb: "4328", apiFootball: 39, name: "Premier League" },
    laliga: { sportsDb: "4335", apiFootball: 140, name: "La Liga" },
    seriea: { sportsDb: "4332", apiFootball: 135, name: "Serie A" },
    bundesliga: { sportsDb: "4331", apiFootball: 78, name: "Bundesliga" },
    ligue1: { sportsDb: "4334", apiFootball: 61, name: "Ligue 1" },
    ucl: { sportsDb: "4480", apiFootball: 2, name: "UEFA Champions League" },
    ksa: { sportsDb: "4668", apiFootball: 307, name: "Saudi Pro League" },
    egy: { sportsDb: "4829", apiFootball: 233, name: "Egyptian Premier League" },
    cafcl: { sportsDb: null, apiFootball: 12, name: "CAF Champions League" }
  };
  return map[id] || null;
}
function todayISO() { return new Date().toISOString().slice(0,10); }
function currentSeasonRange() {
  const d = new Date();
  const y = d.getUTCFullYear();
  const m = d.getUTCMonth() + 1;
  const start = m >= 7 ? y : y - 1;
  return `${start}-${start + 1}`;
}
function normalizeStatus(str) {
  const s = String(str || "").toLowerCase();
  if (s.includes("not started")) return "NS";
  if (s.includes("finished")) return "FT";
  if (s.includes("live")) return "LIVE";
  if (s.includes("postponed")) return "PST";
  return str || "-";
}
module.exports = { json, mapLeagueId, todayISO, currentSeasonRange, normalizeStatus };
