const { json, mapLeagueId, currentSeasonRange } = require('./helpers');
const SPORTSDB_KEY = '123';
async function fetchSportsDbStandings(leagueId) {
  const meta = mapLeagueId(leagueId);
  if (!meta || !meta.sportsDb) return [];
  const url = `https://www.thesportsdb.com/api/v1/json/${SPORTSDB_KEY}/lookuptable.php?l=${meta.sportsDb}&s=${currentSeasonRange()}`;
  try {
    const res = await fetch(url);
    if (!res.ok) return [];
    const data = await res.json();
    const table = Array.isArray(data && data.table) ? data.table : [];
    return table.map((r, i) => ({
      position: Number(r.intRank || i + 1), team: r.strTeam || '', played: Number(r.intPlayed || 0),
      won: Number(r.intWin || 0), draw: Number(r.intDraw || 0), lost: Number(r.intLoss || 0),
      gf: Number(r.intGoalsFor || 0), ga: Number(r.intGoalsAgainst || 0), pts: Number(r.intPoints || 0),
      source: 'TheSportsDB'
    }));
  } catch (e) { return []; }
}
async function fetchApiFootballStandings(leagueId, token) {
  const meta = mapLeagueId(leagueId);
  if (!meta || !meta.apiFootball || !token) return [];
  const season = new Date().getUTCFullYear();
  const url = `https://v3.football.api-sports.io/standings?league=${meta.apiFootball}&season=${season}`;
  try {
    const res = await fetch(url, { headers: { 'x-apisports-key': token } });
    if (!res.ok) return [];
    const data = await res.json();
    const table = data?.response?.[0]?.league?.standings?.[0] || [];
    return table.map(r => ({
      position: r.rank || 0, team: r.team?.name || '', played: r.all?.played || 0, won: r.all?.win || 0,
      draw: r.all?.draw || 0, lost: r.all?.lose || 0, gf: r.all?.goals?.for || 0, ga: r.all?.goals?.against || 0,
      pts: r.points || 0, source: 'API-Football'
    }));
  } catch (e) { return []; }
}
exports.handler = async function(event) {
  try {
    const leagueId = event.queryStringParameters?.league || 'epl';
    const token = process.env.FOOTBALL_DATA_TOKEN || '';
    let standings = await fetchSportsDbStandings(leagueId);
    if ((!standings || !standings.length) && token) standings = await fetchApiFootballStandings(leagueId, token);
    return json(200, { league: leagueId, standings });
  } catch (e) { return json(500, { error: 'Failed to load standings' }); }
};
